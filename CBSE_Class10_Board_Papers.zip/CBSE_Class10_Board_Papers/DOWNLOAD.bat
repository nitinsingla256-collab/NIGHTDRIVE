@echo off
setlocal
title CBSE Class 10 Papers Downloader
color 0F
cd /d "%~dp0"

echo ================================================================
echo   CBSE Class 10 - Question Papers 2019-2027
echo   Subjects: English, Hindi-B, Maths Standard, Science, SST,
echo             Punjabi, Computer Applications
echo ================================================================
echo.
echo Saving to: %~dp0
echo Starting download... DO NOT double-click again!
echo.

set "UA=Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0"
set "C=curl.exe -fsSL --compressed -A "%UA%" --connect-timeout 10 --max-time 45 -o"
set /a OK=0
set /a FAIL=0
set "B=https://cbseacademic.nic.in/web_material/SQP"

REM Prevent re-running by creating a lock
if exist "_downloading.lock" (
    echo Download already running! Please wait...
    pause
    exit /b
)
echo running > "_downloading.lock"

REM ---- 2027 ----
call :get "2027\English\Set-1.pdf"             "%B%/ClassX_2026_27/EnglishL-SQP.pdf"
call :get "2027\Hindi-B\Set-1.pdf"             "%B%/ClassX_2026_27/HindiCourseB-SQP.pdf"
call :get "2027\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2026_27/MathsStandard-SQP.pdf"
call :get "2027\Science\Set-1.pdf"             "%B%/ClassX_2026_27/Science-SQP.pdf"
call :get "2027\Social-Science\Set-1.pdf"      "%B%/ClassX_2026_27/SocialScience-SQP.pdf"
call :get "2027\Punjabi\Set-1.pdf"             "%B%/ClassX_2026_27/Punjabi-SQP.pdf"
call :get "2027\Computer-Applications\Set-1.pdf" "%B%/ClassX_2026_27/ComputerApplication-SQP.pdf"

REM ---- 2026 ----
call :get "2026\English\Set-1.pdf"             "%B%/ClassX_2025_26/EnglishL-SQP.pdf"
call :get "2026\Hindi-B\Set-1.pdf"             "%B%/ClassX_2025_26/HindiCourseB-SQP.pdf"
call :get "2026\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2025_26/MathsStandard-SQP.pdf"
call :get "2026\Science\Set-1.pdf"             "%B%/ClassX_2025_26/Science-SQP.pdf"
call :get "2026\Social-Science\Set-1.pdf"      "%B%/ClassX_2025_26/SocialScience-SQP.pdf"
call :get "2026\Punjabi\Set-1.pdf"             "%B%/ClassX_2025_26/Punjabi-SQP.pdf"
call :get "2026\Computer-Applications\Set-1.pdf" "%B%/ClassX_2025_26/ComputerApplication-SQP.pdf"

REM ---- 2025 ----
call :get "2025\English\Set-1.pdf"             "%B%/ClassX_2024_25/EnglishL-SQP.pdf"
call :get "2025\Hindi-B\Set-1.pdf"             "%B%/ClassX_2024_25/HindiCourseB-SQP.pdf"
call :get "2025\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2024_25/MathsStandard-SQP.pdf"
call :get "2025\Science\Set-1.pdf"             "%B%/ClassX_2024_25/Science-SQP.pdf"
call :get "2025\Social-Science\Set-1.pdf"      "%B%/ClassX_2024_25/SocialScience-SQP.pdf"
call :get "2025\Punjabi\Set-1.pdf"             "%B%/ClassX_2024_25/Punjabi-SQP.pdf"
call :get "2025\Computer-Applications\Set-1.pdf" "%B%/ClassX_2024_25/ComputerApplication-SQP.pdf"

REM ---- 2024 ----
call :get "2024\English\Set-1.pdf"             "%B%/ClassX_2023_24/EnglishL-SQP.pdf"
call :get "2024\Hindi-B\Set-1.pdf"             "%B%/ClassX_2023_24/HindiB-SQP.pdf"
call :get "2024\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2023_24/MathsStandard-SQP.pdf"
call :get "2024\Science\Set-1.pdf"             "%B%/ClassX_2023_24/Science-SQP.pdf"
call :get "2024\Social-Science\Set-1.pdf"      "%B%/ClassX_2023_24/SocialScience-SQP.pdf"
call :get "2024\Punjabi\Set-1.pdf"             "%B%/ClassX_2023_24/Punjabi-SQP.pdf"
call :get "2024\Computer-Applications\Set-1.pdf" "%B%/ClassX_2023_24/ComputerApplication-SQP.pdf"

REM ---- 2023 ----
call :get "2023\English\Set-1.pdf"             "%B%/ClassX_2022_23/EnglishL-SQP.pdf"
call :get "2023\Hindi-B\Set-1.pdf"             "%B%/ClassX_2022_23/HindiCourseB-SQP.pdf"
call :get "2023\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2022_23/MathsStandard-SQP.pdf"
call :get "2023\Science\Set-1.pdf"             "%B%/ClassX_2022_23/Science-SQP.pdf"
call :get "2023\Social-Science\Set-1.pdf"      "%B%/ClassX_2022_23/SocialScience-SQP.pdf"
call :get "2023\Punjabi\Set-1.pdf"             "%B%/ClassX_2022_23/Punjabi-SQP.pdf"
call :get "2023\Computer-Applications\Set-1.pdf" "%B%/ClassX_2022_23/ComputerApplication-SQP.pdf"

REM ---- 2022 (Term 2) ----
call :get "2022\English\Set-1.pdf"             "%B%/ClassX_2021_22/English-LanguageLiterature-SQP.pdf"
call :get "2022\Hindi-B\Set-1.pdf"             "%B%/ClassX_2021_22/HindiB-SQP.pdf"
call :get "2022\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2021_22/MathsStandard-SQP.pdf"
call :get "2022\Science\Set-1.pdf"             "%B%/ClassX_2021_22/Science-SQP.pdf"
call :get "2022\Social-Science\Set-1.pdf"      "%B%/ClassX_2021_22/SocialScience-SQP.pdf"
call :get "2022\Punjabi\Set-1.pdf"             "%B%/ClassX_2021_22/Punjabi-SQP.pdf"
call :get "2022\Computer-Applications\Set-1.pdf" "%B%/ClassX_2021_22/ComputerApplication-SQP.pdf"

REM ---- 2021 (2020-21) - uses HindiCourseB not HindiB ----
call :get "2021\English\Set-1.pdf"             "%B%/ClassX_2020_21/EnglishL-SQP.pdf"
call :get "2021\Hindi-B\Set-1.pdf"             "%B%/ClassX_2020_21/HindiCourseB-SQP.pdf"
call :get "2021\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2020_21/MathsStandard-SQP.pdf"
call :get "2021\Science\Set-1.pdf"             "%B%/ClassX_2020_21/Science-SQP.pdf"
call :get "2021\Social-Science\Set-1.pdf"      "%B%/ClassX_2020_21/SocialScience-SQP.pdf"
call :get "2021\Punjabi\Set-1.pdf"             "%B%/ClassX_2020_21/Punjabi-SQP.pdf"
call :get "2021\Computer-Applications\Set-1.pdf" "%B%/ClassX_2020_21/ComputerApplication-SQP.pdf"

REM ---- 2020 (2019-20) - underscore naming ----
call :get "2020\English\Set-1.pdf"             "%B%/ClassX_2019_20/English-LL_SQP.pdf"
call :get "2020\Hindi-B\Set-1.pdf"             "%B%/ClassX_2019_20/HindiB_SQP.pdf"
call :get "2020\Maths-Standard\Set-1.pdf"      "%B%/ClassX_2019_20/MathematicsStandard_SQP.pdf"
call :get "2020\Science\Set-1.pdf"             "%B%/ClassX_2019_20/Science_SQP.pdf"
call :get "2020\Social-Science\Set-1.pdf"      "%B%/ClassX_2019_20/SocialScience_SQP.pdf"
call :get "2020\Punjabi\Set-1.pdf"             "%B%/ClassX_2019_20/Punjabi_SQP.pdf"
call :get "2020\Computer-Applications\Set-1.pdf" "%B%/ClassX_2019_20/ComputerApplication_SQP.pdf"

REM ---- 2019 (2018-19) - CLASS_X folder, dated filenames ----
call :get "2019\English\Set-1.pdf"             "%B%/CLASS_X_2018_19/X-English_LANG_LIT_SQP_2019.pdf"
call :get "2019\Hindi-B\Set-1.pdf"             "%B%/CLASS_X_2018_19/X-Hindi-B_SQP_2018-19.pdf"
call :get "2019\Maths-Standard\Set-1.pdf"      "%B%/CLASS_X_2018_19/X-Maths_SQP_2018-19.pdf"
call :get "2019\Science\Set-1.pdf"             "%B%/CLASS_X_2018_19/X_Science_SQP_2018-19.pdf"
call :get "2019\Social-Science\Set-1.pdf"      "%B%/CLASS_X_2018_19/X-SS_SQP_2018-19.pdf"
call :get "2019\Punjabi\Set-1.pdf"             "%B%/CLASS_X_2018_19/X-Punjabi_SQP_2018-19.pdf"
call :get "2019\Computer-Applications\Set-1.pdf" "%B%/CLASS_X_2018_19/X-FIT_SQP%%202018-19.pdf" "%B%/CLASS_X_2018_19/X-ICT-SQP_2018-19.pdf"

del "_downloading.lock" >nul 2>&1

echo.
echo ================================================================
echo   FINISHED!  Successfully downloaded: %OK%   Failed: %FAIL%
echo ================================================================
echo.
echo Opening 2027\English folder to show you the files...
start "" explorer.exe "%~dp02027\English"
echo.
pause
exit /b

:get
REM Args:  outpath  url1 [url2]
set "OUT=%~dp0%~1"
set "URL=%~2"
for %%F in ("%OUT%") do set "OD=%%~dpF"
if not exist "%OD%" mkdir "%OD%"
<nul set /p "=  %~1 ... "
if exist "%OUT%" (
    for %%A in ("%OUT%") do if %%~zA GTR 2000 (
        echo SKIP
        set /a OK+=1
        exit /b
    )
)
%c% "%OUT%" "%URL%"
if errorlevel 1 (
    if not "%~3"=="" (
        REM try fallback URL
        %c% "%OUT%" "%~3"
        if not errorlevel 1 (goto :getok)
    )
    echo FAILED
    if exist "%OUT%" del "%OUT%"
    set /a FAIL+=1
    exit /b
)
:getok
for %%A in ("%OUT%") do set /a KB=%%~zA/1024
echo OK - %KB% KB
set /a OK+=1
exit /b
